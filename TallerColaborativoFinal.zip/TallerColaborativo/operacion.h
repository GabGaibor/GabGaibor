#ifndef OPERACION_H
#define OPERACION_H

#define PRODUCTOS 100
#define NOMBRE 50
#define CLIENTES 100
#define CEDULA 11
#define FACTURAS 100

void ingresarProducto(int*, char[][NOMBRE], int[], float[]);
void editarProducto(int*, char[][NOMBRE], int[], float[], char*);
void eliminarProducto(int*, char[][NOMBRE], int[], float[], char*);
void listarProductos(int, char[][NOMBRE], int[], float[]);
void cargarInventario(int*, char[][NOMBRE], int[], float[]);
void guardarInventario(int, char[][NOMBRE], int[], float[]);

void ingresarCliente(char[][NOMBRE], char[][CEDULA], int*);
void modificarCliente(char[][NOMBRE], char[][CEDULA], int);
void consultarCliente(char[][NOMBRE], char[][CEDULA], int);
void listarClientes(char[][NOMBRE], char[][CEDULA], int);
void guardarClientes(char[][NOMBRE], char[][CEDULA], int);
void cargarClientes(char[][NOMBRE], char[][CEDULA], int*);
void eliminarCliente(char[][NOMBRE], char[][CEDULA], int*);
int cedulaValida(char*);
int cedulaUnica(char*, char[][CEDULA], int);

void guardarFacturas(int cantidadFacturas, char cedulasClientes[][CEDULA], char nombresClientes[][NOMBRE], float valoresPagados[], int cantidadesProductos[]);
void cargarFacturas(int* cantidadFacturas, char cedulasClientes[][CEDULA], char nombresClientes[][NOMBRE], float valoresPagados[], int cantidadesProductos[]);
void facturar(int cantidadProductos, char nombresProductos[][NOMBRE], int cantidades[], float precios[], int cantidadClientes, char cedulasClientes[][CEDULA], char nombresClientes[][NOMBRE], int* cantidadFacturas, char cedulasFacturas[][CEDULA], char nombresFacturas[][NOMBRE], float valoresPagados[], int cantidadesProductos[]);
void listarFacturas(int cantidadFacturas, char cedulasFacturas[][CEDULA], char nombresFacturas[][NOMBRE], float valoresPagados[], int cantidadesProductos[]);
void buscarFactura(int cantidadFacturas, char cedulasFacturas[][CEDULA], char nombresFacturas[][NOMBRE], float valoresPagados[], int cantidadesProductos[]);

#endif

