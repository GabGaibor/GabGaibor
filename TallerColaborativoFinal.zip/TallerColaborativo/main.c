#include <stdio.h>
#include "lectura.h"
#include "operacion.h"

int main() {
    int cantidadProductos = 0;
    char nombresProductos[PRODUCTOS][NOMBRE];
    int cantidades[PRODUCTOS];
    float precios[PRODUCTOS];

    char nombresClientes[CLIENTES][NOMBRE];
    char cedulas[CLIENTES][CEDULA];
    int cantidadClientes = 0;

    int cantidadFacturas = 0;
    char cedulasFacturas[FACTURAS][CEDULA];
    char cedulasClientes[NOMBRE][CEDULA];
    char nombresFacturas[FACTURAS][NOMBRE];
    float valoresPagados[FACTURAS];
    int cantidadesProductos[FACTURAS];

    int opcion;
    cargarInventario(&cantidadProductos, nombresProductos, cantidades, precios);
    cargarClientes(nombresClientes, cedulas, &cantidadClientes);
    cargarFacturas(&cantidadFacturas, cedulasFacturas, nombresFacturas, valoresPagados, cantidadesProductos);

    do {
        printf("\nSistema de Gestión de Inventario y Facturacion\n");
        printf("1. Ingresar producto\n");
        printf("2. Editar producto\n");
        printf("3. Eliminar producto\n");
        printf("4. Listar productos\n");
        printf("5. Ingresar cliente\n");
        printf("6. Modificar cliente\n");
        printf("7. Consultar cliente\n");
        printf("8. Listar clientes\n");
        printf("9. Eliminar clientes\n");
        printf("10. Facturar\n");
        printf("11. Buscar factura\n");
        printf("12. Listar facturas\n");
        printf("13. Salir\n");
        opcion = leerEnteroEntre("Seleccione una opcion: ", 1, 12);

        switch(opcion) {
            case 1:
                ingresarProducto(&cantidadProductos, nombresProductos, cantidades, precios);
                break;
            case 2: {
                char nombreProducto[NOMBRE];
                printf("Ingrese el nombre del producto a editar: ");
                scanf("%s", nombreProducto);
                editarProducto(&cantidadProductos, nombresProductos, cantidades, precios, nombreProducto);
                break;
            }
            case 3: {
                char nombreProducto[NOMBRE];
                printf("Ingrese el nombre del producto a eliminar: ");
                scanf("%s", nombreProducto);
                eliminarProducto(&cantidadProductos, nombresProductos, cantidades, precios, nombreProducto);
                break;
            }
            case 4:
                listarProductos(cantidadProductos, nombresProductos, cantidades, precios);
                break;
            case 5:
                ingresarCliente(nombresClientes, cedulas, &cantidadClientes);
                break;
            case 6:
                modificarCliente(nombresClientes, cedulas, cantidadClientes);
                break;
            case 7:
                consultarCliente(nombresClientes, cedulas, cantidadClientes);
                break;
            case 8:
                listarClientes(nombresClientes, cedulas, cantidadClientes);
                break;
            case 9:
                eliminarCliente(nombresClientes, cedulas, &cantidadClientes);
                break;
            case 10:
                guardarFacturas(cantidadFacturas, cedulasClientes, nombresClientes, valoresPagados,cantidadesProductos);
                break;
            case 11:
                buscarFactura(cantidadFacturas, cedulasFacturas, nombresFacturas, valoresPagados, cantidadesProductos);
                break;
            case 12:
                 listarFacturas(cantidadFacturas, cedulasFacturas, nombresFacturas, valoresPagados, cantidadesProductos);
                break;
            case 13:
                printf("Saliendo del programa...\n");
                break;
            default:
                printf("Opcion no valida.\n");
                break;
        }
    } while(opcion != 13);

    return 0;
}
