#define PRODUCTOS 100
#define NOMBRE 50

void ingresarProducto(int*, char[][NOMBRE], int[], float[]);
void editarProducto(int*, char[][NOMBRE], int[], float[], char*);
void eliminarProducto(int*, char[][NOMBRE], int[], float[], char*);
void listarProductos(int*, char[][NOMBRE], int[], float[]);
void cargarInventario(int*, char[][NOMBRE], int[], float[]);

