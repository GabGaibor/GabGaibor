#include <stdio.h>
#include <string.h>
#include "lectura.h"
#include "operacion.h"

void guardarInventario(int cantidadProductos, char nombres[][NOMBRE], int cantidades[], float precios[]) {
    FILE* archivo = fopen("inventario.txt", "w");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo para guardar.\n");
        return;
    }

    fprintf(archivo, "%d\n", cantidadProductos);
    for (int i = 0; i < cantidadProductos; i++) {
        fprintf(archivo, "%s %d %.2f\n", nombres[i], cantidades[i], precios[i]);
    }

    fclose(archivo);
}

void cargarInventario(int* cantidadProductos, char nombres[][NOMBRE], int cantidades[], float precios[]) {
    FILE* archivo = fopen("inventario.txt", "r");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo para cargar.\n");
        return;
    }

    fscanf(archivo, "%d", cantidadProductos);
    for (int i = 0; i < *cantidadProductos; i++) {
        fscanf(archivo, "%s %d %f", nombres[i], &cantidades[i], &precios[i]);
    }

    fclose(archivo);
}

void ingresarProducto(int* cantidadProductos, char nombres[][NOMBRE], int cantidades[], float precios[]) {
    if (*cantidadProductos >= PRODUCTOS) {
        printf("Inventario lleno. No se pueden agregar más productos.\n");
        return;
    }

    char nombreProducto[NOMBRE];
    printf("Ingrese el nombre del producto: ");
    scanf("%s", nombreProducto);

    if (!productoUnico(nombreProducto, nombres, *cantidadProductos)) {
        printf("El producto ya existe en el inventario.\n");
        return;
    }

    strcpy(nombres[*cantidadProductos], nombreProducto);
    cantidades[*cantidadProductos] = leerEntero("Ingrese la cantidad del producto: ");
    precios[*cantidadProductos] = leerFlotantePositivo("Ingrese el precio del producto: ");
    (*cantidadProductos)++;

    guardarInventario(*cantidadProductos, nombres, cantidades, precios);
    printf("Producto ingresado exitosamente.\n");
}

int productoUnico(char* nombreProducto, char nombres[][NOMBRE], int cantidadProductos) {
    for (int i = 0; i < cantidadProductos; i++) {
        if (strcmp(nombres[i], nombreProducto) == 0) {
            return 0;
        }
    }
    return 1;
}


void editarProducto(int* cantidadProductos, char nombres[][NOMBRE], int cantidades[], float precios[], char* nombreProducto) {
    for (int i = 0; i < *cantidadProductos; i++) {
        if (strcmp(nombres[i], nombreProducto) == 0) {
            printf("Producto encontrado. Ingrese los nuevos datos.\n");
            printf("Nuevo nombre: ");
            scanf("%s", nombres[i]);
            
            cantidades[i] = leerEntero("Ingrese la nueva cantidad del producto: ");
            precios[i] = leerFlotantePositivo("Ingrese el nuevo precio del producto: ");

            guardarInventario(*cantidadProductos, nombres, cantidades, precios);
            printf("Producto editado exitosamente.\n");
            return;
        }
    }
    printf("Producto no encontrado.\n");
}

void eliminarProducto(int* cantidadProductos, char nombres[][NOMBRE], int cantidades[], float precios[], char* nombreProducto) {
    for (int i = 0; i < *cantidadProductos; i++) {
        if (strcmp(nombres[i], nombreProducto) == 0) {
            for (int j = i; j < *cantidadProductos - 1; j++) {
                strcpy(nombres[j], nombres[j + 1]);
                cantidades[j] = cantidades[j + 1];
                precios[j] = precios[j + 1];
            }
            (*cantidadProductos)--;

            guardarInventario(*cantidadProductos, nombres, cantidades, precios);
            printf("Producto eliminado exitosamente.\n");
            return;
        }
    }
    printf("Producto no encontrado.\n");
}

void listarProductos(int cantidadProductos, char nombres[][NOMBRE], int cantidades[], float precios[]) {
    printf("Inventario:\n");
    for (int i = 0; i < cantidadProductos; i++) {
        printf("Producto: %s, Cantidad: %d, Precio: %.2f\n", nombres[i], cantidades[i], precios[i]);
    }
}

void guardarClientes(char nombres[][NOMBRE], char cedulas[][CEDULA], int cantidadClientes) {
    FILE* archivo = fopen("clientes.txt", "w");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo para guardar.\n");
        return;
    }

    fprintf(archivo, "%d\n", cantidadClientes);
    for (int i = 0; i < cantidadClientes; i++) {
        fprintf(archivo, "%s %s\n", nombres[i], cedulas[i]);
    }

    fclose(archivo);
}

void cargarClientes(char nombres[][NOMBRE], char cedulas[][CEDULA], int* cantidadClientes) {
    FILE* archivo = fopen("clientes.txt", "r");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo para cargar.\n");
        return;
    }

    fscanf(archivo, "%d", cantidadClientes);
    for (int i = 0; i < *cantidadClientes; i++) {
        fscanf(archivo, "%s %s", nombres[i], cedulas[i]);
    }

    fclose(archivo);
}

void ingresarCliente(char nombres[][NOMBRE], char cedulas[][CEDULA], int* cantidadClientes) {
    if (*cantidadClientes >= CLIENTES) {
        printf("Límite de clientes alcanzado.\n");
        return;
    }

    char nombreCliente[NOMBRE];
    printf("Ingrese el nombre del cliente: ");
    scanf("%s", nombreCliente);

    if (!nombreClienteUnico(nombreCliente, nombres, *cantidadClientes)) {
        printf("El nombre del cliente ya existe.\n");
        return;
    }

    do {
        printf("Ingrese la cédula del cliente: ");
        scanf("%s", cedulas[*cantidadClientes]);
    } while (!cedulaValida(cedulas[*cantidadClientes]) || !cedulaUnica(cedulas[*cantidadClientes], cedulas, *cantidadClientes));

    strcpy(nombres[*cantidadClientes], nombreCliente);
    (*cantidadClientes)++;
    guardarClientes(nombres, cedulas, *cantidadClientes);
    printf("Cliente ingresado exitosamente.\n");
}

int nombreClienteUnico(char* nombreCliente, char nombres[][NOMBRE], int cantidadClientes) {
    for (int i = 0; i < cantidadClientes; i++) {
        if (strcmp(nombres[i], nombreCliente) == 0) {
            return 0;
        }
    }
    return 1;
}



void modificarCliente(char nombres[][NOMBRE], char cedulas[][CEDULA], int cantidadClientes) {
    char cedula[CEDULA];
    printf("Ingrese la cedula del cliente a modificar: ");
    scanf("%s", cedula);

    for (int i = 0; i < cantidadClientes; i++) {
        if (strcmp(cedulas[i], cedula) == 0) {
            printf("Cliente encontrado. Ingrese los nuevos datos.\n");
            printf("Nuevo nombre: ");
            scanf("%s", nombres[i]);

            do {
                printf("Nueva cedula: ");
                scanf("%s", cedulas[i]);
            } while (!cedulaValida(cedulas[i]) || !cedulaUnica(cedulas[i], cedulas, cantidadClientes));

            guardarClientes(nombres, cedulas, cantidadClientes);
            printf("Cliente modificado exitosamente.\n");
            return;
        }
    }
    printf("Cliente no encontrado.\n");
}

void consultarCliente(char nombres[][NOMBRE], char cedulas[][CEDULA], int cantidadClientes) {
    char cedula[CEDULA];
    printf("Ingrese la cedula del cliente a consultar: ");
    scanf("%s", cedula);

    for (int i = 0; i < cantidadClientes; i++) {
        if (strcmp(cedulas[i], cedula) == 0) {
            printf("Cliente encontrado:\nNombre: %s\nCedula: %s\n", nombres[i], cedulas[i]);
            return;
        }
    }
    printf("Cliente no encontrado.\n");
}

void listarClientes(char nombres[][NOMBRE], char cedulas[][CEDULA], int cantidadClientes) {
    printf("Lista de clientes:\n");
    for (int i = 0; i < cantidadClientes; i++) {
        printf("Nombre: %s, Cedula: %s\n", nombres[i], cedulas[i]);
    }
}

void eliminarCliente(char nombres[][NOMBRE], char cedulas[][CEDULA], int* cantidadClientes) {
    char cedula[CEDULA];
    printf("Ingrese la cedula del cliente a eliminar: ");
    scanf("%s", cedula);

    for (int i = 0; i < *cantidadClientes; i++) {
        if (strcmp(cedulas[i], cedula) == 0) {
            for (int j = i; j < *cantidadClientes - 1; j++) {
                strcpy(nombres[j], nombres[j + 1]);
                strcpy(cedulas[j], cedulas[j + 1]);
            }
            (*cantidadClientes)--;

            guardarClientes(nombres, cedulas, *cantidadClientes);
            printf("Cliente eliminado exitosamente.\n");
            return;
        }
    }
    printf("Cliente no encontrado.\n");
}

int cedulaValida(char* cedula) {
    int n = strlen(cedula);
    if (n != 10) return 0;

    int provincia = (cedula[0] - '0') * 10 + (cedula[1] - '0');
    if (provincia < 0 || provincia > 24) return 0;

    int tercerDigito = cedula[2] - '0';
    if (tercerDigito < 0 || tercerDigito > 5) return 0;

    int coef[] = {2, 1, 2, 1, 2, 1, 2, 1, 2};
    int suma = 0;
    for (int i = 0; i < 9; i++) {
        int digito = cedula[i] - '0';
        int prod = digito * coef[i];
        suma += (prod >= 10) ? prod - 9 : prod;
    }

    int decenaSuperior = ((suma + 9) / 10) * 10;
    int digitoVerificador = decenaSuperior - suma;

    return (digitoVerificador == (cedula[9] - '0'));
}

int cedulaUnica(char* cedula, char cedulas[][CEDULA], int cantidadClientes) {
    for (int i = 0; i < cantidadClientes; i++) {
        if (strcmp(cedulas[i], cedula) == 0) {
            return 0;
        }
    }
    return 1;
}

void guardarFacturas(int cantidadFacturas, char cedulasClientes[][CEDULA], char nombresClientes[][NOMBRE], float valoresPagados[], int cantidadesProductos[]) {
    FILE* archivo = fopen("facturas.txt", "w");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo para guardar.\n");
        return;
    }

    fprintf(archivo, "%d\n", cantidadFacturas);
    for (int i = 0; i < cantidadFacturas; i++) {
        fprintf(archivo, "%s %s %.2f %d\n", cedulasClientes[i], nombresClientes[i], valoresPagados[i], cantidadesProductos[i]);
    }

    fclose(archivo);
}

void cargarFacturas(int* cantidadFacturas, char cedulasClientes[][CEDULA], char nombresClientes[][NOMBRE], float valoresPagados[], int cantidadesProductos[]) {
    FILE* archivo = fopen("facturas.txt", "r");
    if (archivo == NULL) {
        printf("No se pudo abrir el archivo para cargar.\n");
        return;
    }

    fscanf(archivo, "%d", cantidadFacturas);
    for (int i = 0; *cantidadFacturas > 0 && i < *cantidadFacturas; i++) {
        fscanf(archivo, "%s %s %f %d", cedulasClientes[i], nombresClientes[i], &valoresPagados[i], &cantidadesProductos[i]);
    }

    fclose(archivo);
}

void facturar(int cantidadProductos, char nombresProductos[][NOMBRE], int cantidades[], float precios[], int cantidadClientes, char cedulasClientes[][CEDULA], char nombresClientes[][NOMBRE], int* cantidadFacturas, char cedulasFacturas[][CEDULA], char nombresFacturas[][NOMBRE], float valoresPagados[], int cantidadesProductos[]) {
    if (*cantidadFacturas >= FACTURAS) {
        printf("No se pueden registrar más facturas.\n");
        return;
    }

    char cedula[CEDULA];
    printf("Ingrese la cédula del cliente: ");
    scanf("%s", cedula);

    int clienteIndex = -1;
    for (int i = 0; i < cantidadClientes; i++) {
        if (strcmp(cedulasClientes[i], cedula) == 0) {
            clienteIndex = i;
            break;
        }
    }

    if (clienteIndex == -1) {
        printf("Cliente no encontrado.\n");
        return;
    }

    int cantidadComprada = leerEntero("Ingrese la cantidad de productos comprados: ");
    float valorTotal = 0;

    for (int i = 0; i < cantidadComprada; i++) {
        char nombreProducto[NOMBRE];
        printf("Ingrese el nombre del producto: ");
        scanf("%s", nombreProducto);

        int productoIndex = -1;
        for (int j = 0; j < cantidadProductos; j++) {
            if (strcmp(nombresProductos[j], nombreProducto) == 0) {
                productoIndex = j;
                break;
            }
        }

        if (productoIndex == -1) {
            printf("Producto no encontrado.\n");
            return;
        }

        int cantidadProducto = leerEntero("Ingrese la cantidad del producto: ");
        if (cantidadProducto > cantidades[productoIndex]) {
            printf("No hay suficiente cantidad del producto.\n");
            return;
        }

        cantidades[productoIndex] -= cantidadProducto;
        valorTotal += cantidadProducto * precios[productoIndex];
    }

    strcpy(cedulasFacturas[*cantidadFacturas], cedulasClientes[clienteIndex]);
    strcpy(nombresFacturas[*cantidadFacturas], nombresClientes[clienteIndex]);
    valoresPagados[*cantidadFacturas] = valorTotal;
    cantidadesProductos[*cantidadFacturas] = cantidadComprada;

    (*cantidadFacturas)++;
    guardarFacturas(*cantidadFacturas, cedulasFacturas, nombresFacturas, valoresPagados, cantidadesProductos);
    guardarInventario(cantidadProductos, nombresProductos, cantidades, precios);
    printf("Factura registrada exitosamente.\n");
}

void listarFacturas(int cantidadFacturas, char cedulasFacturas[][CEDULA], char nombresFacturas[][NOMBRE], float valoresPagados[], int cantidadesProductos[]) {
    printf("Lista de facturas:\n");
    for (int i = 0; i < cantidadFacturas; i++) {
        printf("Factura %d: Cliente %s (%s), Valor pagado: %.2f, Cantidad de productos: %d\n", i + 1, nombresFacturas[i], cedulasFacturas[i], valoresPagados[i], cantidadesProductos[i]);
    }
}

void buscarFactura(int cantidadFacturas, char cedulasFacturas[][CEDULA], char nombresFacturas[][NOMBRE], float valoresPagados[], int cantidadesProductos[]) {
    char cedula[CEDULA];
    printf("Ingrese la cédula del cliente de la factura a buscar: ");
    scanf("%s", cedula);

    for (int i = 0; i < cantidadFacturas; i++) {
        if (strcmp(cedulasFacturas[i], cedula) == 0) {
            printf("Factura encontrada:\nCliente %s (%s), Valor pagado: %.2f, Cantidad de productos: %d\n", nombresFacturas[i], cedulasFacturas[i], valoresPagados[i], cantidadesProductos[i]);
            return;
        }
    }
    printf("Factura no encontrada.\n");
}

void aumentarStock(int cantidadProductos, char nombres[][NOMBRE], int cantidades[], float precios[]) {
    char nombreProducto[NOMBRE];
    int cantidadAumentar;

    printf("Ingrese el nombre del producto para aumentar el stock: ");
    scanf("%s", nombreProducto);

    int encontrado = 0;
    for (int i = 0; i < cantidadProductos; i++) {
        if (strcmp(nombres[i], nombreProducto) == 0) {
            printf("Ingrese la cantidad a aumentar: ");
            scanf("%d", &cantidadAumentar);
            cantidades[i] += cantidadAumentar;
            printf("Stock actualizado. Nueva cantidad de %s: %d\n", nombres[i], cantidades[i]);
            encontrado = 1;
            break;
        }
    }

    if (!encontrado) {
        printf("Producto no encontrado.\n");
    }

    guardarInventario(cantidadProductos, nombres, cantidades, precios); 
}
