#define PRODUCTOS 100
#define NOMBRE 50

typedef struct {
    char nombre[NOMBRE];
    int cantidad;
    float precio;
} Producto;