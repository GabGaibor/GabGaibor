#include "producto.h"

void ingresarProducto(int*, Producto[]);
void editarProducto(int*, Producto[], char*);
void eliminarProducto(int*, Producto[], char*);
void listarProductos(int*, Producto[]);

