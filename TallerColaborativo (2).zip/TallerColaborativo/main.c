#include <stdio.h>
#include "operacion.h"

#define PRODUCTOS 100
#define NOMBRE 50

int main() {
    int opcion;
    char nombres[PRODUCTOS][NOMBRE];
    int cantidades[PRODUCTOS];
    float precios[PRODUCTOS];
    int cantidadProductos = 0; 
    char nombreProducto[NOMBRE];

    do {
        printf("\nSistema de Inventarios\n");
        printf("1. Ingresar producto\n");
        printf("2. Editar producto\n");
        printf("3. Eliminar producto\n");
        printf("4. Listar productos\n");
        printf("5. Salir\n");
        printf("Ingrese una opcion: ");
        scanf("%d", &opcion);

        switch (opcion) {
            case 1:
                ingresarProducto(&cantidadProductos, nombres, cantidades, precios);
                break;
            case 2:
                printf("Ingrese el nombre del producto a editar: ");
                scanf("%s", nombreProducto);
                editarProducto(&cantidadProductos, nombres, cantidades, precios, nombreProducto);
                break;
            case 3:
                printf("Ingrese el nombre del producto a eliminar: ");
                scanf("%s", nombreProducto);
                eliminarProducto(&cantidadProductos, nombres, cantidades, precios, nombreProducto);
                break;
            case 4:
                listarProductos(&cantidadProductos, nombres, cantidades, precios);
                break;
            case 5:
                printf("Saliendo del sistema de inventarios.\n");
                break;
            default:
                printf("Opcion no valida. Intente de nuevo.\n");
        }
    } while (opcion != 5);

    return 0;
}